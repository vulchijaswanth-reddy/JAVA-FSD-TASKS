package com.starhealth.excep.demo;

public class ArithExcep {

	int numOne = 100;

	int numTwo = 10;

	public void addNum() throws ArithmeticException {

		System.out.println(numOne / numTwo);
	}

	public static void main(String[] args) {
		
		
		ArithExcep oj = new ArithExcep();
		
		try{oj.addNum();
		
		}catch(ArithmeticException e) {
			
			//e.printStackTrace();
			
			System.out.println("END");
			
		}
		
		
		
	}

}
