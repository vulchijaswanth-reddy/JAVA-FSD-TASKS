package com.starhealth.excep.demo;

public class DemoThreads extends Thread {

	
	
	@Override
	public void run() {
		
		System.out.println(" Thread Running !!");
	}
	
	
	public static void main(String[] args) { //main thread
		
		
		DemoThreads oj = new DemoThreads();
		
		DemoThreads oj2 = new DemoThreads();
		
		oj2.setName("Jashwanth");
		
		oj2.setPriority(Thread.MAX_PRIORITY-2);
		
		oj.setName("Jashwanth Reddy");
		
		oj.setPriority(Thread.MAX_PRIORITY-1);
		
		
		System.out.println(oj2.getName());
		
		System.out.println(oj.getName());
		
		System.out.println(oj);
		System.out.println(oj2);
		
		
		System.out.println(oj);
		
		oj.start(); // it will call run method internally
		oj2.start();
		
		
		
	}
		
	}



