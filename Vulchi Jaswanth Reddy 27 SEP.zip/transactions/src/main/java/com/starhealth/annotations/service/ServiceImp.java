package com.starhealth.annotations.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.annotations.beans.Payments;
import com.starhealth.annotations.repo.Irepo;
import com.starhealth.annotations.repo.RepoImp;


@Service
public class ServiceImp implements Iservice {
	
	//Irepo obj = new RepoImp();
	
	@Autowired
	Irepo obj;

	public int addInfo(Payments pay) {
		
		return obj.addInfo(pay);
	}

	public int updateInfo(Payments pay) {
		
		return obj.updateInfo(pay);
	}

	public int deleteInfo(int transactionId) {
		return obj.deleteInfo(transactionId);
	}

	public Payments selectInfo(int transactionId) {
		return obj.selectInfo(transactionId);
	}

	public List<Payments> selectAll() {
	return obj.selectAll();
	}

}
