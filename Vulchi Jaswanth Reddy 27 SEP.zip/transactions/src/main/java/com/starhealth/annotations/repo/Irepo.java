package com.starhealth.annotations.repo;

import java.util.List;

import com.starhealth.annotations.beans.Payments;

public interface Irepo {
	
	public int addInfo(Payments pay);
	
	public int updateInfo(Payments pay);
	
	public int deleteInfo(int transactionId);
	
	public Payments selectInfo(int transactionId);
	
	public List <Payments> selectAll();
	
	

}
