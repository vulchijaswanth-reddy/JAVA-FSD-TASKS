package com.starhealth.annotations.service;

import java.util.List;

import com.starhealth.annotations.beans.Payments;

public interface Iservice {
	
	public int addInfo(Payments pay);
	
	public int updateInfo(Payments pay);
	
	public int deleteInfo(int transactionId);
	
	public Payments selectInfo(int transactionId);
	
	public List <Payments> selectAll();

}
