package com.starhealth.annotations.ui;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages= {"com.starhealth.annonations.*"})
public class Config {
	
	

}
