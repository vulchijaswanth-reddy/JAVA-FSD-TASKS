package com.starhealth.annotations.repo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.starhealth.annotations.beans.Payments;


@Repository
public class RepoImp implements Irepo {

	Connection con = DbUtility.getConnect();

	public int addInfo(Payments pay) {
		int count = 0;

		try {

			String query = "insert into payments(transactionId, name, amount, date) values(?,?,?,?)";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setInt(1, pay.getTransactionId());
			pt.setString(2, pay.getName());
			pt.setDouble(3, pay.getAmount());
			pt.setString(4, pay.getDate());

			count = pt.executeUpdate();

			System.out.println(count + "Records Updated..");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
	}

	public int updateInfo(Payments pay) {

		int count = 0;

		try {

			String query = "update payments set name=?, amount=?, date=? where transactionId=?";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setString(1, pay.getName());
			pt.setDouble(2, pay.getAmount());
			pt.setString(3, pay.getDate());
			pt.setInt(4, pay.getTransactionId());

			count = pt.executeUpdate();

			// System.out.println(count + "Records Updated..");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return count;
	}

	public int deleteInfo(int transactionId) {

		int deleteCount = 0;

		try {

			String query = "delete from payments where transactionId=?";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setInt(1, transactionId);

			deleteCount = pt.executeUpdate();

			System.out.println(deleteCount + "Records Deleted...");

		} catch (Exception e) {
			e.printStackTrace();
		}

		return deleteCount;
	}

	public Payments selectInfo(int transactionId) {

		Payments pay = new Payments();

		try {

			String query = "select * from payments where transactionId= ?";

			PreparedStatement pt = con.prepareStatement(query);

			pt.setInt(1, transactionId);

			ResultSet rs = pt.executeQuery();

			while (rs.next()) {

				pay.setTransactionId(rs.getInt("transactionId"));
				pay.setName(rs.getString("name"));
				pay.setAmount(rs.getDouble("amount"));
				pay.setDate(rs.getString("date"));

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return pay;
	}

	public List<Payments> selectAll() {

		String query = "select * from payments";

		PreparedStatement pt;

		List<Payments> list = new ArrayList<Payments>();

		try {

			pt = con.prepareStatement(query);

			ResultSet rs = pt.executeQuery();

			

			while (rs.next()) {
				
				Payments pay = new Payments();

				pay.setTransactionId(rs.getInt("transactionId"));
				pay.setName(rs.getString("name"));
				pay.setAmount(rs.getDouble("amount"));
				pay.setDate(rs.getString("date"));

				list.add(pay);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

}
