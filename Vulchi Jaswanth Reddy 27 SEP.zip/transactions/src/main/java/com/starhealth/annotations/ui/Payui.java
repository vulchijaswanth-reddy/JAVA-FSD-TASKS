package com.starhealth.annotations.ui;

import java.io.ObjectInputFilter.Config;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.starhealth.annotations.beans.Payments;
import com.starhealth.annotations.service.Iservice;
import com.starhealth.annotations.service.ServiceImp;

public class Payui {
	
	static Payments pay;

	public static void main(String[] args) {
		
		ApplicationContext con = new AnnotationConfigApplicationContext(Config.class);
		
		Iservice ser = con.getBean(ServiceImp.class);
		
		pay = con.getBean(Payments.class);

		//Iservice ser = new ServiceImp();

		boolean flag = true;

		while (flag) {

			System.out.println("*** PAYMENTS RECORDS ***");

			System.out.println("1. insert new payment info ");

			System.out.println("2. update payment info ");

			System.out.println("3. delete payment info ");

			System.out.println("4. select payment info by id ");

			System.out.println("5. select all information");

			System.out.println("Exit");

			Scanner sc = new Scanner(System.in);

			int opt = sc.nextInt();

			switch (opt) {
			case 1:

				Payments pay = dataIn();

				int count = ser.addInfo(pay);

				System.out.println(count + "Records Updated...");

				break;
			case 2:

				Payments pay3 = dataIn();

				int updateCount = ser.updateInfo(pay3);

				System.out.println(updateCount + "Records Updated...");

				break;

			case 3:

				int transactionId = sc.nextInt();

				int deleteCount = ser.deleteInfo(transactionId);

				System.out.println(deleteCount + "Record Deleted..");

				break;

			case 4:

				int transId = sc.nextInt();

				Payments pay4 = ser.selectInfo(transId);

				System.out.println(pay4);

				break;

			case 5:

				List<Payments> list = ser.selectAll();

			Stream<Payments> stream = list.stream();
			stream.forEach(System.out::println);
				
				
				break;

			case 6:

				flag = false;

				System.out.println("Thanks !!");

				break;

			default:
				break;
			}

		}

	}

	public static Payments dataIn() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Transaction Id");

		int transactionId = sc.nextInt();

		System.out.println("Enter Name");

		String name = sc.next();

		System.out.println("Enter Amount");

		double amount = sc.nextInt();

		System.out.println("Enter Date");

		DateTimeFormatter dt = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		String date = sc.next();

		LocalDate ld = LocalDate.parse(date, dt);

		//Payments pay = new Payments();

		pay.setTransactionId(transactionId);
		pay.setName(name);
		pay.setAmount(amount);
		pay.setDate(date);

		return pay;

	}

}
