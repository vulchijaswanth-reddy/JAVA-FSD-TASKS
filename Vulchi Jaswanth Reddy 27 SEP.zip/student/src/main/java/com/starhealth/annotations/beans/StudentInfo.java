package com.starhealth.annotations.beans;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("stu")
@Scope("prototype")
public class StudentInfo {
	
	private int stuNo;
	private String stuname;
	private double stuFee;

	
	public StudentInfo() {
		super();
	}


	public StudentInfo(int stuNo, String stuname, double stuFee) {
		super();
		this.stuNo = stuNo;
		this.stuname = stuname;
		this.stuFee = stuFee;
	}


	public int getStuNo() {
		return stuNo;
	}


	public void setStuNo(int stuNo) {
		this.stuNo = stuNo;
	}


	public String getStuname() {
		return stuname;
	}


	public void setStuname(String stuname) {
		this.stuname = stuname;
	}


	public double getStuFee() {
		return stuFee;
	}


	public void setStuFee(double stuFee) {
		this.stuFee = stuFee;
	}
	
}
