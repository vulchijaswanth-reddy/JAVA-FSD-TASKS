package com.starhealth.annotations.repo;

public interface IstudentRepo {
	
	public void display();

}
