package com.starhealth.annotations.repo;

import org.springframework.stereotype.Repository;

@Repository
public class StudentRepoImp implements IstudentRepo {

	@Override
	public void display() {
		
		System.out.println("Student Repo Implementation Class...");
		
	}

}
