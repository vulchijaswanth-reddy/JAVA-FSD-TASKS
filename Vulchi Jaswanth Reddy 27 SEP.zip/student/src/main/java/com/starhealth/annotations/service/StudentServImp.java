package com.starhealth.annotations.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.annotations.repo.IstudentRepo;

@Service
public class StudentServImp implements IstudentServ {
	
	@Autowired
	IstudentRepo ref;

	@Override
	public void getServ() {
		System.out.println("Student Service Implementation Class...");

	}

}
