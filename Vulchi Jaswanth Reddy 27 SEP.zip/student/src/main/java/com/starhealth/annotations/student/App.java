package com.starhealth.annotations.student;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.starhealth.annotations.beans.StudentInfo;
import com.starhealth.annotations.repo.IstudentRepo;
import com.starhealth.annotations.repo.StudentRepoImp;
import com.starhealth.annotations.service.IstudentServ;
import com.starhealth.annotations.service.StudentServImp;

@Configuration
@ComponentScan(basePackages = { "com.starhealth.annotations.*" })
public class App {
	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(App.class);

		StudentInfo si = context.getBean("stu",StudentInfo.class);

		System.out.println(si);
		
		si.setStuNo(1);
		si.setStuname("Jashwanth");
		si.setStuFee(500);
		
		IstudentServ ser = context.getBean(StudentServImp.class);
		
		System.out.println(ser);
		
		IstudentRepo rep = context.getBean(StudentRepoImp.class);
		
		System.out.println(rep);

	}
}
