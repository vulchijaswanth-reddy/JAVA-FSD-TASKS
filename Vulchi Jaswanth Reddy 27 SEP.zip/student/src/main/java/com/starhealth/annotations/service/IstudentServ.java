package com.starhealth.annotations.service;

public interface IstudentServ {
	
	public void getServ();

}
