package mypack;

public class DemoFirstProgram {
	
	

	public static void main(String[] args) {
		
		int num = 33;
		byte id = 21;
		short count = -22;
		double marks = 45;
		long totalMarks = 434343;
		float pass= 50.5f;
		char letter = 'd';
		boolean flag = false;
		
		String studentName = "Jashwanth";
		
		System.out.println(num);
		
		num = (int) pass;
		
		
		System.out.println(num);
		System.out.println(id);
		System.out.println(count);
		System.out.println(marks);
		System.out.println(totalMarks);
		System.out.println(pass);
		System.out.println(letter);
		System.out.println(studentName);
		System.out.println(flag);

	}

}
