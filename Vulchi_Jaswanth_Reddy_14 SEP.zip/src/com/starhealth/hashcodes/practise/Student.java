package com.starhealth.hashcodes.practise;

import java.util.Objects;

public class Student {
	
	
	public Student() {
		super();
	}
	
	

	private String stuName;
	private int stuId;
	private double stuFee;
	

	public Student(String stuName, int stuId, double stuFee) {
		super();
		this.stuName = stuName;
		this.stuId = stuId;
		this.stuFee = stuFee;
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public int getStuId() {
		return stuId;
	}

	public void setStuId(int stuId) {
		this.stuId = stuId;
	}

	public double getStuFee() {
		return stuFee;
	}

	public void setStuFee(double stuFee) {
		this.stuFee = stuFee;
	}

	
	@Override
	public String toString() {
		return "Student [stuName=" + stuName + ", stuId=" + stuId + ", stuFee=" + stuFee + "]";
	}

	@Override
	public int hashCode() {
		return stuId;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		return Double.doubleToLongBits(stuFee) == Double.doubleToLongBits(other.stuFee) && stuId == other.stuId
				&& Objects.equals(stuName, other.stuName);
	}
	
	
	
	
	
}
