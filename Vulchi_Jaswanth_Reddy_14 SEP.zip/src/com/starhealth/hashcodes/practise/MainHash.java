package com.starhealth.hashcodes.practise;

public class MainHash {
	
	public static void main(String[] args) {
		
		
		Student ss = new Student("Jashwanth Reddy", 3, 3000);
		Student ss1 = new Student("Jashwanth Reddy", 3, 3000);
		
		System.out.println(ss + " " + ss.hashCode());
		
		System.out.println(ss1 + " " + ss1.hashCode());
		
	    System.out.println(ss.equals(ss1));
	    
	    System.out.println(ss == ss1);
	    
	  //  System.out.println(ss+ " " + ss1);
	    
	  //  System.out.println(ss.hashCode() + " " + ss1.hashCode());
	    
	    
	 //   Student ss1 = ss;
	    
	//    System.out.println(ss1.equals(ss) + " " + ss1.hashCode() + " "+ss.hashCode());
	    
	    
		
		
		
		
		
		
		
		
	}

}
