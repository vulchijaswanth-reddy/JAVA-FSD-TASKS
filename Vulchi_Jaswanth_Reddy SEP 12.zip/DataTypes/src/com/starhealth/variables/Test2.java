package com.starhealth.variables;

public class Test2 {
	
	
	
	public static void main(String[] args) {
		
		System.out.println(Employee.empContact);
		
		
		Employee obj = new Employee(1, "Aanand", 300, 8000);
		
		Employee obj2 = new Employee(2,"Chowdary",100,9000);
		
		
		System.out.println(obj.getEmpId()+" "+ obj.getEmpName()+" "+obj.getEmpTotal()+" "+obj.getEmpFee());
		
		
		System.out.println(obj2.getEmpId()+" "+ obj2.getEmpName()+" "+obj2.getEmpTotal()+" "+obj2.getEmpFee());
		
		Employee obj3 = new Employee();
		obj3.setEmpId(2);
		obj3.setEmpName("Jashwanth");
		
		System.out.println(obj3.getEmpId()+" "+ obj3.getEmpName()+" "+obj3.getEmpTotal()+" "+obj3.getEmpFee());
		
	}

}
