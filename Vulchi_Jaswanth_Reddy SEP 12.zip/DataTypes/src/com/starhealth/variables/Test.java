package com.starhealth.variables;

public class Test {
	
	
	
	public static void main(String[] args) {
		
		System.out.println(Student.stuContact);
		
		
		Student obj = new Student(1, "Jashwanth", 300, 3000);
		
		Student obj2 = new Student(2,"Reddy",200,2000);
		
		
		System.out.println(obj.getStuId()+" "+ obj.getStuName()+" "+obj.getStuTotal()+" "+obj.getStuFee());
		
		
		System.out.println(obj2.getStuId()+" "+ obj2.getStuName()+" "+obj2.getStuTotal()+" "+obj2.getStuFee());
		
		Student obj3 = new Student();
		obj3.setStuId(2);
		obj3.setStuName("John");
		
		System.out.println(obj3.getStuId()+" "+ obj3.getStuName()+" "+obj3.getStuTotal()+" "+obj3.getStuFee());
		
	}

}
