package com.starhealth.variables;

public class LocalVariables {

	float jash = 33.33f;
	int rollNo = 22;

	public void display() {

		System.out.println(jash);

	}

	public void show() {

		System.out.println(jash);
		
		if (rollNo > 10) {

			float jas = 54.4f;
			
			

		}
	}
	

	public static void main(String[] args) {
		
		

		LocalVariables reff = new LocalVariables();
		

		System.out.println(reff.jash);
		
		//System.out.println(jas);

		

		
	}

}
