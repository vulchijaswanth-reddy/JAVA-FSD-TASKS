package com.starhealth.variables;

public class Student {
	
private	int stuId;
private	String stuName;
private	float stuTotal;
private	double stuFee;
	
	static int stuContact = 12345;

	
	public Student(int stuId, String stuName, float stuTotal, double stuFee) {
		super();
		this.stuId = stuId;
		this.stuName = stuName;
		this.stuTotal = stuTotal;
		this.stuFee = stuFee;
	}




	public int getStuId() {
		return stuId;
	}




	public void setStuId(int stuId) {
		this.stuId = stuId;
	}




	public String getStuName() {
		return stuName;
	}




	public void setStuName(String stuName) {
		this.stuName = stuName;
	}




	public float getStuTotal() {
		return stuTotal;
	}




	public void setStuTotal(float stuTotal) {
		this.stuTotal = stuTotal;
	}




	public double getStuFee() {
		return stuFee;
	}




	public void setStuFee(double stuFee) {
		this.stuFee = stuFee;
	}




	public Student() {
		super();
	
	}




}
