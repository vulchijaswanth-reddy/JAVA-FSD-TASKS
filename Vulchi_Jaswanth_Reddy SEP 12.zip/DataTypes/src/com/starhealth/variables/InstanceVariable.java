package com.starhealth.variables;

public class InstanceVariable {
	
	// instance variables are only accessible with in the class itself.
	
	int varOne;
	String varName; 
	private int idName = 34;
	
	public static void main(String[] args) {
		
		// But, Instance variables can access outside of the class through objects
		
		InstanceVariable obj = new InstanceVariable();
		
		
		System.out.println(obj.varOne);
		System.out.println(obj.varName);
		
		obj.display();
		
		
	}
public void display() {
		
		System.out.println(idName);
	}

	
	
}
