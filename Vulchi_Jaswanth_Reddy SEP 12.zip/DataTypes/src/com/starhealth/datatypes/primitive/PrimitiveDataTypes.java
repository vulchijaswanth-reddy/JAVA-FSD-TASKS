package com.starhealth.datatypes.primitive;

public class PrimitiveDataTypes extends Object {
	
	public static void main(String args[]) {
		
	 long mobileNo = 9999999999L;
	 
	 int j = (byte)mobileNo;
	 
	// byte jj = 129; 
	 
	 
	
		
	//	System.out.println());
		
	}

}
