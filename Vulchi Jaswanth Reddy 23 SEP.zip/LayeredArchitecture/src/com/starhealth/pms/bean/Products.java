package com.starhealth.pms.bean;

public class Products {
	
	private int sno;
	private String proName;
	private int cost;
	
	public Products() {
		
		
	}
	
	
	
	public Products(int sno, String proName, int cost) {
		super();
		this.sno = sno;
		this.proName = proName;
		this.cost = cost;
	}



	public int getSno() {
		return sno;
	}



	public void setSno(int sno) {
		this.sno = sno;
	}



	public String getProName() {
		return proName;
	}



	public void setProName(String proName) {
		this.proName = proName;
	}



	public int getCost() {
		return cost;
	}



	public void setCost(int cost) {
		this.cost = cost;
	}



	@Override
	public String toString() {
		return "Products [sno=" + sno + ", proName=" + proName + ", cost=" + cost + "]";
	}
	
	

}
