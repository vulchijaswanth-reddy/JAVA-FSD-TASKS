package com.starhealth.pms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	
public static Connection getCon() {
		
		Connection con = null;
		
		try {
			DriverManager.registerDriver(new com.mysql.cj.jdbc.Driver());
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/starhealth_db", "root", "J@sh1th24");
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return con;

}}
