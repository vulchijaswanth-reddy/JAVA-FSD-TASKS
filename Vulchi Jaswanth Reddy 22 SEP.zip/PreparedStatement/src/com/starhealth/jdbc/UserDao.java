package com.starhealth.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDao {

	Connection con = UtilityDB.getCon();

	public int addUser(UserInfo obj) {

		int count = 0;
		try {

			String insertQuery = "insert into user_info(token_id,name,mobile,city,DOB) values(?,?,?,?,?)";
			PreparedStatement pst = con.prepareStatement(insertQuery);

			pst.setInt(1, obj.getToken_id());
			pst.setString(2, obj.getName());
			pst.setString(3, obj.getMobile());
			pst.setString(4, obj.getCity());
			pst.setString(5, obj.getDOB());

			count = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;

	}

	public int updateUser(UserInfo obj) {
		int count = 0;
		try {

			String insertQuery = "update user_info set name=?, mobile=?, city=?, DOB=?  where token_id=?";
			PreparedStatement pst = con.prepareStatement(insertQuery);

			pst.setInt(1, obj.getToken_id());
			pst.setString(2, obj.getName());
			pst.setString(3, obj.getMobile());
			pst.setString(4, obj.getCity());
			pst.setString(5, obj.getDOB());

			count = pst.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
		return count;

	}

	public UserInfo selectUser(int token_id) {


			String selectQuery = "select * from user_info where token_id = ?";
			PreparedStatement pstmt;

			UserInfo ui = new UserInfo();

			try {
				pstmt = con.prepareStatement(selectQuery);

				pstmt.setInt(1, token_id);

				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {

					ui.setToken_id(rs.getInt("token_id"));
					ui.setName(rs.getString("name"));
					ui.setMobile(rs.getString("mobile"));
					ui.setCity(rs.getString("city"));
					ui.setDOB(rs.getString("DOB"));

				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			return ui;
	}

	public int deleteUser(int token_id) {

		String deleteQuery = "delete from user_info where token_id = ?";
		PreparedStatement pstmt;
		int deleteCount = 0;
		try {
			pstmt = con.prepareStatement(deleteQuery);

			pstmt.setInt(1, token_id);

			deleteCount = pstmt.executeUpdate();

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return deleteCount;

	}

	public List<UserInfo> selectAllUser() {

		String selectQuery = "select * from user_info";
		PreparedStatement psmt;

		List<UserInfo> list = new ArrayList<UserInfo>();
		try {
			psmt = con.prepareStatement(selectQuery);

			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {

				UserInfo ui = new UserInfo();

				ui.setToken_id(rs.getInt("token_id"));
				ui.setName(rs.getString("name"));
				ui.setMobile(rs.getString("mobile"));
				ui.setCity(rs.getString("city"));
				ui.setDOB(rs.getString("DOB"));

				list.add(ui);

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		return list;

	}

}
