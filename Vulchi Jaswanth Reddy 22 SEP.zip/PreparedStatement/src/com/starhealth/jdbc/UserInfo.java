package com.starhealth.jdbc;

public class UserInfo {
	
	private int token_id;
	private String name;
	private String mobile;
	private String city;
	private String DOB;
	
	
	public UserInfo() {
		
		
	}	
	
	public UserInfo(int token_id, String name, String mobile, String city, String dOB) {
		super();
		this.token_id = token_id;
		this.name = name;
		this.mobile = mobile;
		this.city = city;
		DOB = dOB;
	}


	public int getToken_id() {
		return token_id;
	}


	public void setToken_id(int token_id) {
		this.token_id = token_id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getMobile() {
		return mobile;
	}


	public void setMobile(String mobile) {
		this.mobile = mobile;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getDOB() {
		return DOB;
	}


	public void setDOB(String dOB) {
		DOB = dOB;
	}

	@Override
	public String toString() {
		return "UserInfo [token_id=" + token_id + ", name=" + name + ", mobile=" + mobile + ", city=" + city + ", DOB="
				+ DOB + "]";
	}
	
	
	

}
