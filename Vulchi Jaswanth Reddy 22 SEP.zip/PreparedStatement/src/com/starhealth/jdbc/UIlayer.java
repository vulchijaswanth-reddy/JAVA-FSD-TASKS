package com.starhealth.jdbc;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Stream;

public class UIlayer {

	public static void main(String[] args) {

		UserDao dao = new UserDao();

		UserInfo ui = new UserInfo();

		Scanner sc = new Scanner(System.in);

		boolean flag = true;

		while (flag) {

			System.out.println("USER INFO MANAGEMENT SYSTEM");

			System.out.println("1. Add user details");
			System.out.println("2. Update user details");
			System.out.println("3. Delete user details");
			System.out.println("4. Select user details");
			System.out.println("5. Select all user details");
			System.out.println("6. EXIT");

			int choice = sc.nextInt();

			switch (choice) {
			case 1:

				UserInfo obj = indata();

				int count = dao.addUser(obj);
				System.out.println(count + "Records effected...");

				break;
			case 2:
				UserInfo obj2 = indata();
				int updateCount = dao.updateUser(obj2);
				
				System.out.println(updateCount+" record updated successfully");

				break;
			case 3:
				int deleteId = sc.nextInt();

				int deleteCount = dao.deleteUser(deleteId);

				System.out.println(deleteCount + "record deleted ...");

				break;
			case 4:
				System.out.println("Enter Id to Select One Record");
				int searchId = sc.nextInt();

				UserInfo ui1 = dao.selectUser(searchId);

				System.out.println(ui1);

				break;

			case 5:
				List<UserInfo> list = dao.selectAllUser();

				Stream<UserInfo> stream = list.stream();

				stream.forEach(System.out::println);

				break;

			case 6:

				System.out.println("Thank You !!");

				flag = false;

				break;

			default:
				throw new IllegalArgumentException("Unexpected value: " + choice);
			}
		}

	}

	public static UserInfo indata() {

		Scanner sc = new Scanner(System.in);

		System.out.println("token Id");
		int token_id = sc.nextInt();

		System.out.println("name");
		String name = sc.next();

		System.out.println("mobile");
		String mobile = sc.next();

		System.out.println("city");
		String city = sc.next();

		System.out.println("DOB");

		DateTimeFormatter dobj = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		String DOB = sc.next();

		LocalDate lobj = LocalDate.parse(DOB, dobj);

		UserInfo obj = new UserInfo();

		obj.setToken_id(token_id);
		obj.setName(name);
		obj.setMobile(mobile);
		obj.setCity(city);
		obj.setDOB(DOB);

		return obj;

	}

}
