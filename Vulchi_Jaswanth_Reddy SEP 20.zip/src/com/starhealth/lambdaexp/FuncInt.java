package com.starhealth.lambdaexp;

public interface FuncInt {
	
//	public int add(int a, int b); //Function Functional Interface 
	
//	public int show();    // Supplier Functional Interface
	
//	public void display(String s); //Consumer Functional Interface
	
//	public void show();  //Supplier Functional Interface
	
	
	public static void mul() {
	
		
		System.out.println("I belongs to Interface");
	}

	
	public boolean dis(int a);
	
}
