package com.starhealth.springrest.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.starhealth.springrest.entity.Insurance;

@Repository
public interface InsuRepo extends JpaRepository<Insurance, Integer> {

}
