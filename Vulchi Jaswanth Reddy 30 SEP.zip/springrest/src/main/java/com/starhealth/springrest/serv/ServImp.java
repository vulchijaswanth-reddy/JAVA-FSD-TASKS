package com.starhealth.springrest.serv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.springrest.entity.Insurance;
import com.starhealth.springrest.repo.InsuRepo;

import antlr.collections.List;

@Service
public class ServImp implements InsuServ {

	@Autowired
	InsuRepo repo;

	@Override
	public Insurance addInfo(Insurance ins) {

		return repo.save(ins);
	}

	@Override
	public Insurance updateInfo(Insurance ins) {
		return repo.save(ins);
	}

	@Override
	public Insurance selectInfoById(int insuranceNo) {
		return repo.findById(insuranceNo).orElse(null);
	}

	@Override
	public void deleteByNo(int insuranceNo) {
		repo.deleteById(insuranceNo);

	}

	@Override
	public List selectAllInfo() {
		// TODO Auto-generated method stub
		return (List) repo.findAll();
	}

}
