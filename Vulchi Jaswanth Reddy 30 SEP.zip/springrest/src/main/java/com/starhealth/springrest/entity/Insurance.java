package com.starhealth.springrest.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
@Entity
@Table(name="insurance_info")
public class Insurance {
	
	@Id
	private int insuranceNo;
	private String name;
	private double amount;

}
