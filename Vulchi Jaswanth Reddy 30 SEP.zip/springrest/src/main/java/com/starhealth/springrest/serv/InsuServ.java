package com.starhealth.springrest.serv;

import com.starhealth.springrest.entity.Insurance;

import antlr.collections.List;

public interface InsuServ {
	
	public Insurance addInfo(Insurance in);
	
	public Insurance updateInfo(Insurance in);
	
	public Insurance selectInfoById(int insuranceNo);
	
	public void deleteByNo(int insuranceNo);
	
	public List selectAllInfo();
	
	
	

}
