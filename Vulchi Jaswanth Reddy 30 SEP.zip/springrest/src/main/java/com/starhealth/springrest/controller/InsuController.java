package com.starhealth.springrest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.springrest.entity.Insurance;
import com.starhealth.springrest.serv.InsuServ;

import antlr.collections.List;

@RestController
@RequestMapping("/api/v1/insurance")
public class InsuController {
	
	@Autowired
	InsuServ ser;
	
	@PostMapping("/add")
	public Insurance add(@RequestBody Insurance ins) {
		
		return ser.addInfo(ins);
	}
	
	
	@PostMapping("/update")
	public Insurance update(@RequestBody Insurance ins) {
		
		return ser.updateInfo(ins);
	}
	
	
	@DeleteMapping("/delete/{insuranceNo}")
	public String delete(@PathVariable int insuranceNo) {
		
		ser.deleteByNo(insuranceNo);
		
		return "delete record successfully...";
		
	}
	
	@GetMapping("/select/{insuranceNo}")
	public Insurance selectbyid(@PathVariable int insuranceNo) {
		
		return ser.selectInfoById(insuranceNo);
		
		
	}
	
	/*
	 * @GetMapping("/get") public List <Insurance> getall(){
	 * 
	 * return ser.selectAllInfo();
	 * 
	 * 
	 * }
	 */
	
	
	
	

}
