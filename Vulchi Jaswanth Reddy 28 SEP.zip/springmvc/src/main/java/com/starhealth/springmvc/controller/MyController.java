package com.starhealth.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/api")
public class MyController {
	
	
	@RequestMapping(value = "/diss", method=RequestMethod.GET)
	@ResponseBody
	public void diss() {
		
		System.out.println("Hello There !!");
	}
	
	@RequestMapping(value = "/data", method=RequestMethod.GET)
	@ResponseBody
	public String data() {
		
		return "Jashwanth Here !!";
	}

}
