package com.starhealth.springnine.repo;

public interface Irepo {
	
	public void dis();

}
