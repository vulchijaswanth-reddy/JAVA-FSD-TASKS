package com.starhealth.springnine.serv;

public interface Iserv {
	
	
	
	public void details();

}
