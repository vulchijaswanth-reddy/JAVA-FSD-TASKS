package com.starhealth.springnine.repo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.starhealth.springnine.beans.Mobiles;

@Repository
public class RepoImp implements Irepo {
	
	@Autowired
	Mobiles mob;
	
	

	@Override
	public void dis() {
		mob.setName("Jashwanth");
		mob.setCost(1000);
		
		System.out.println(mob);

	}

}
