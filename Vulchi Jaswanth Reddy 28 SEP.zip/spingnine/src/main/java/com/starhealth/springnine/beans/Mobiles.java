package com.starhealth.springnine.beans;

import lombok.Data;

import lombok.NoArgsConstructor;

import lombok.ToString;

@NoArgsConstructor
@ToString
@Data
public class Mobiles {

	private String name;
	private int cost;

}
