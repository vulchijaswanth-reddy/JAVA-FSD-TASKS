package com.starhealth.springnine.serv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.springnine.repo.Irepo;

@Service
public class ServImp implements Iserv {
	
	@Autowired
	Irepo re;

	
	public void details() {
		
		re.dis();
		
		
	}
	
	
	

}
