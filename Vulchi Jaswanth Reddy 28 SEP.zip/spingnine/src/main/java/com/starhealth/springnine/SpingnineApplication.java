package com.starhealth.springnine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.starhealth.springnine.beans.Mobiles;
import com.starhealth.springnine.serv.Iserv;
import com.starhealth.springnine.serv.ServImp;

@SpringBootApplication
public class SpingnineApplication {

	@Bean
	public Mobiles getProductObj() {

		return new Mobiles();

	}

	public static void main(String[] args) {
		ApplicationContext con = SpringApplication.run(SpingnineApplication.class, args);

		Iserv ref = con.getBean(ServImp.class);

		ref.details();
		
		

	}

}
