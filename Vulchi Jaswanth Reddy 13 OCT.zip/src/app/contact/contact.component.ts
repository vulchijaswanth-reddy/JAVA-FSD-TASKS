import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Contact } from './contact';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  obj:Contact ={"name":"","email":"","message":""}

  name:string="";

  email:string="";

  id:number=22;


  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  getFormData(data:Contact){

    this.name = data.name;
    this.email = data.email;

    console.log(this.name + " " + this.email)

    if(this.name == "jashwanth" && this.email == "jash@gmail.com"){

      this.router.navigate(['about/'+this.id])
    }



    
  }

}
