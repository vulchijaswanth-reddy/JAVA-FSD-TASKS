package com.starhealth.customer.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.customer.entity.Customer;

public interface IcustomerRepo extends JpaRepository<Customer, Integer> {

}
