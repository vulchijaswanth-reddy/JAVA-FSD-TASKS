package com.starhealth.customer.serv;

import com.starhealth.customer.entity.Customer;

public interface IcustomerServ {
	
	public Customer addCustomer(Customer cus);
	
	public Customer getCustomerById(int cid);

}
