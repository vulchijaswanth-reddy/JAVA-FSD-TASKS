package com.starhealth.customer.serv;

import javax.websocket.server.ServerEndpoint;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.starhealth.customer.entity.Customer;
import com.starhealth.customer.repo.IcustomerRepo;

@Service
public class CustomerServ implements IcustomerServ {
	
	@Autowired
	IcustomerRepo repo;

	@Override
	public Customer addCustomer(Customer cus) {
		return repo.save(cus);
	}

	@Override
	public Customer getCustomerById(int cid) {
		return repo.findById(cid).orElse(new Customer());
	}

}
