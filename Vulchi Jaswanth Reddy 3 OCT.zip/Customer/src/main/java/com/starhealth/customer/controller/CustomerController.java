package com.starhealth.customer.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.customer.entity.Customer;
import com.starhealth.customer.serv.IcustomerServ;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {

	@Autowired
	IcustomerServ serv;

	@PostMapping("/add")
	public Customer addCustomer(@RequestBody Customer cus) {

		return serv.addCustomer(cus);

	}

	@GetMapping("/get/{cid}")
	public Customer getCustomerById(@PathVariable int cid) {

		return serv.getCustomerById(cid);
	}

}
