package com.starhealth.product.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Data
public class Customer { //POJO CLASS

	private int cid;
	private String CName;

}