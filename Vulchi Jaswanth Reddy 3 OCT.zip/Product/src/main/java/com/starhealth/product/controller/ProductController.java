package com.starhealth.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.starhealth.product.entity.Product;
import com.starhealth.product.serv.IproductServ;
import com.starhealth.product.vo.ProductCustomer;

@RestController
@RequestMapping("/api/Products")
public class ProductController {

	@Autowired
	IproductServ serv;

	@PostMapping("/add")
	public Product addProduct(@RequestBody Product prod) {

		return serv.addProduct(prod);

	}

	@GetMapping("/get/{pid}")
	public Product getProductById(@PathVariable int pid) {
		
		return serv.getProductById(pid);
		
	}
	
	@GetMapping("/get/customer/{cid}")
	public ProductCustomer getCustomerWithProductId(@PathVariable int pid) {
		
		return serv.getCustomerWithProductId(pid);
	}

}


