package com.starhealth.product.vo;

import com.starhealth.product.entity.Product;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ProductCustomer {
	
	private Product product;
	private Customer customer;

}
