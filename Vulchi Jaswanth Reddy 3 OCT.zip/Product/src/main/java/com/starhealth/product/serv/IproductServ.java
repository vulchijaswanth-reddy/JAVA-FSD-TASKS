package com.starhealth.product.serv;

import com.starhealth.product.entity.Product;
import com.starhealth.product.vo.ProductCustomer;

public interface IproductServ {
	
	public Product addProduct(Product prod);
	
	public Product getProductById(int pid);
	
	public ProductCustomer getCustomerWithProductId(int pid);

}
