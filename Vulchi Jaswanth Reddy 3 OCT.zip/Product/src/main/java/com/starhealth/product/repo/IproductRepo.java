package com.starhealth.product.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.starhealth.product.entity.Product;

public interface IproductRepo extends JpaRepository<Product, Integer> {

}
