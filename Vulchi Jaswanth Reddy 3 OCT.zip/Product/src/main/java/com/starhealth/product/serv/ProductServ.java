package com.starhealth.product.serv;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.starhealth.product.entity.Product;
import com.starhealth.product.repo.IproductRepo;
import com.starhealth.product.vo.Customer;
import com.starhealth.product.vo.ProductCustomer;

@Service
public class ProductServ implements IproductServ {

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	IproductRepo repo;

	@Override
	public Product addProduct(Product prod) {
		return repo.save(prod);
	}

	@Override
	public Product getProductById(int pid) {
		return repo.findById(pid).orElse(new Product());
	}

	@Override
	public ProductCustomer getCustomerWithProductId(int pid) {

		Product prd = getProductById(pid);

		int cid = prd.getCid();

		Customer customer = restTemplate.getForObject("http://localhost:8282/api/products/get/" + cid, Customer.class);
         
		ProductCustomer pd = new ProductCustomer(prd, customer);
		
		return pd;
		
		
	}

}
