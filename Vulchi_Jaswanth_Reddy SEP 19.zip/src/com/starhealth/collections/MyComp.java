package com.starhealth.collections;

import java.util.Comparator;

public class MyComp implements Comparator<Customer>{

	@Override
	public int compare(Customer o1, Customer o2) {
		
		String s1 = o1.toString();
		
		String s2 = o2.toString();
		
		
		return s1.compareTo(s2);
	}
	
	

}
