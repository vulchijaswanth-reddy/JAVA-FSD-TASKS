package com.starhealth.collections;

import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

public class HashMapDemo {
	
	public static void main(String[] args) {
		
		Map<Integer,String> oj = new Hashtable<Integer,String>();
		
		oj.put(1, "Jash");
		oj.put(3, "Coffee");
		oj.put(2, "Student");
		oj.put(3, "Mobile");
		oj.put(4, "Bike");
		
		System.out.println(oj);
		
		System.out.println(oj.keySet());
		System.out.println(oj.values());
		System.out.println(oj.get(4));
		
		
		Set <Integer> ol = oj.keySet();
		
		for (Integer key : ol) {
			
			System.out.println(key +" "+oj.get(key));
			
		}
		
		
		
	}

}
